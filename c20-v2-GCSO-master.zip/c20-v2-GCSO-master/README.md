### Global Car Safety Organization using Sprites

#### Description : Global Car Safety Organisation which conducts test for reliability of car in the event of crash
#### Output Link : https://vishnupriya-whitehatjr.github.io/c20-v2-GCSO/index.html
